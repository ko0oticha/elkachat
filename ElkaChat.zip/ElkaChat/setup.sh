#!/bin/bash

# Скрипт автоматической установки ElkaChat для Ubuntu
set -e

echo "=== Установка ElkaChat (VLESS + E2EE) ==="

# 1. Проверка прав root
if [ "$EUID" -ne 0 ]; then
  echo "Пожалуйста, запустите скрипт от имени root (sudo ./setup.sh)"
  exit
fi

# 2. Сбор данных
read -p "Введите ваш домен (например, elkachat.mooo.com): " DOMAIN
if [ -z "$DOMAIN" ]; then
  echo "Домен не может быть пустым."
  exit 1
fi

# 3. Установка Docker, если он не установлен
if ! command -v docker &> /dev/null; then
    echo "Установка Docker..."
    apt-get update
    apt-get install -y ca-certificates curl gnupg
    install -m 0755 -d /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
    chmod a+r /etc/apt/keyrings/docker.gpg
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
    apt-get update
    apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
fi

# 4. Генерация ключей для Reality
echo "Генерация криптографических ключей..."
# Используем временный контейнер xray для генерации ключей
KEYS=$(docker run --rm teddysun/xray:latest xray x25519)
PRIVATE_KEY=$(echo "$KEYS" | grep "Private key:" | awk '{print $3}')
PUBLIC_KEY=$(echo "$KEYS" | grep "Public key:" | awk '{print $3}')
SHORT_ID=$(openssl rand -hex 8)

# 5. Настройка конфигурации Xray
echo "Настройка xray_config.json..."
cat <<EOF > backend/xray_config.json
{
  "inbounds": [
    {
      "port": 443,
      "protocol": "vless",
      "settings": {
        "clients": [{ "id": "$(cat /proc/sys/kernel/random/uuid)", "flow": "xtls-rprx-vision" }],
        "decryption": "none"
      },
      "streamSettings": {
        "network": "tcp",
        "security": "reality",
        "realitySettings": {
          "show": false,
          "dest": "google.com:443",
          "xver": 0,
          "serverNames": ["google.com", "www.google.com"],
          "privateKey": "$PRIVATE_KEY",
          "shortIds": ["$SHORT_ID"]
        }
      }
    }
  ],
  "outbounds": [{ "protocol": "freedom", "tag": "direct" }]
}
EOF

# 6. Обновление Frontend (WSS адрес)
# Исправленный путь: frontend/index.html
if [ -f "frontend/index.html" ]; then
    echo "Обновление адреса сервера во фронтенде..."
    sed -i "s/your-secure-server.com/$DOMAIN/g" frontend/index.html
else
    echo "Предупреждение: frontend/index.html не найден. Проверьте структуру папок."
fi

# 7. Запуск через Docker Compose
echo "Запуск контейнеров..."
docker compose up -d --build

echo ""
echo "=== УСТАНОВКА ЗАВЕРШЕНА ==="
echo "Ваш мессенджер доступен по адресу: http://$DOMAIN (или https://$DOMAIN)"
echo "Ваш Public Key для Reality: $PUBLIC_KEY"
echo "Ваш Short ID: $SHORT_ID"
echo "==========================="
echo "Не забудьте настроить A-запись для $DOMAIN на IP этого сервера."
