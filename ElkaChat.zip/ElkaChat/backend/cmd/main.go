package main

import (
	"elkachat-backend/internal/api"
	"github.com/gin-gonic/gin"
	"log"
)

func main() {
	r := gin.Default()

	// Группа API для работы с пользователями и ключами
	v1 := r.Group("/api/v1")
	{
		v1.POST("/register", api.RegisterUser)
		v1.POST("/keys/bundle", api.UploadBundle)
		v1.GET("/keys/bundle/:id", api.GetBundle)
	}

	// WebSocket для обмена сообщениями и пуш-уведомлений
	r.GET("/ws", api.HandleWebSocket)

	log.Println("Server starting on :8080...")
	// В продакшене лучше запускать на 8080 за Xray/Nginx прокси
	if err := r.Run(":8080"); err != nil {
		log.Fatal(err)
	}
}
