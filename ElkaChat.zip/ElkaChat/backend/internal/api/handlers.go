package api

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"net/http"
	"time"

	"elkachat-backend/internal/models"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
)

// В реальном приложении здесь будет PostgreSQL. Для примера используем in-memory мапы.
var users = make(map[string]models.User)
var bundles = make(map[string]models.KeyBundle)

// RegisterUser регистрирует нового пользователя с SHA-256
func RegisterUser(c *gin.Context) {
	var input struct {
		Username string `json:"username" binding:"required"`
		Password string `json:"password" binding:"required"`
	}

	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Генерируем соль для защиты от радужных таблиц
	salt := uuid.New().String()
	hash := hashPassword(input.Password, salt)

	newUser := models.User{
		ID:           uuid.New().String(),
		Username:     input.Username,
		PasswordHash: hash,
		Salt:         salt,
		CreatedAt:    time.Now(),
	}

	// Простая проверка уникальности (в БД это делает gorm:"unique")
	for _, u := range users {
		if u.Username == input.Username {
			c.JSON(http.StatusConflict, gin.H{"error": "Username already exists"})
			return
		}
	}

	users[newUser.ID] = newUser
	c.JSON(http.StatusCreated, newUser)
}

// UploadBundle загружает публичные ключи для E2EE
func UploadBundle(c *gin.Context) {
	var bundle models.KeyBundle
	if err := c.ShouldBindJSON(&bundle); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	bundles[bundle.UserID] = bundle
	c.JSON(http.StatusOK, gin.H{"status": "bundle updated"})
}

// GetBundle отдает ключи пользователя, чтобы начать с ним чат
func GetBundle(c *gin.Context) {
	userID := c.Param("id")
	bundle, ok := bundles[userID]
	if !ok {
		c.JSON(http.StatusNotFound, gin.H{"error": "Key bundle not found"})
		return
	}

	c.JSON(http.StatusOK, bundle)
}

// hashPassword выполняет хеширование пароля через SHA-256 с солью
func hashPassword(password, salt string) string {
	hasher := sha256.New()
	hasher.Write([]byte(password + salt))
	return hex.EncodeToString(hasher.Sum(nil))
}
