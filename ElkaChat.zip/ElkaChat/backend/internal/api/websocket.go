package api

import (
	"log"
	"net/http"
	"sync"

	"github.com/gin-gonic/gin"
	"github.com/gorilla/websocket"
)

var upgrader = websocket.Upgrader{
	CheckOrigin: func(r *http.Request) bool {
		return true // Для Flutter Web в разработке разрешаем все Origin
	},
}

// Clients хранит активные соединения по UserID
var clients = make(map[string]*websocket.Conn)
var mu sync.Mutex

// HandleWebSocket обрабатывает входящие сокет-соединения
func HandleWebSocket(c *gin.Context) {
	userID := c.Query("user_id")
	if userID == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "user_id is required"})
		return
	}

	conn, err := upgrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		log.Printf("WS upgrade error: %v", err)
		return
	}

	mu.Lock()
	clients[userID] = conn
	mu.Unlock()

	defer func() {
		mu.Lock()
		delete(clients, userID)
		mu.Unlock()
		conn.Close()
	}()

	// Цикл чтения сообщений
	for {
		var msg struct {
			ReceiverID string `json:"receiver_id"`
			Payload    string `json:"payload"` // Зашифровано E2EE (ChaCha20)
		}

		err := conn.ReadJSON(&msg)
		if err != nil {
			log.Printf("WS read error: %v", err)
			break
		}

		// Пересылка сообщения получателю
		mu.Lock()
		receiverConn, ok := clients[msg.ReceiverID]
		mu.Unlock()

		if ok {
			err = receiverConn.WriteJSON(gin.H{
				"sender_id": userID,
				"payload":   msg.Payload,
				"type":      "new_message", // Тип для обработки уведомления на клиенте
			})
			if err != nil {
				log.Printf("WS write error: %v", err)
			}
		} else {
			// Здесь можно сохранить сообщение в очередь (Redis/DB) 
			// для доставки, когда получатель будет онлайн
			log.Printf("User %s is offline", msg.ReceiverID)
		}
	}
}
