package models

import "time"

// User представляет пользователя мессенджера
type User struct {
	ID           string    `json:"id"`
	Username     string    `json:"username" gorm:"unique"`
	PasswordHash string    `json:"-"`
	Salt         string    `json:"-"`
	CreatedAt    time.Time `json:"created_at"`
}

// KeyBundle содержит публичные ключи пользователя для протокола X3DH (E2EE)
// Это то, что другой пользователь скачивает перед началом чата
type KeyBundle struct {
	UserID         string   `json:"user_id"`
	IdentityKey    string   `json:"identity_key"`     // Публичный ключ идентичности
	SignedPreKey   string   `json:"signed_pre_key"`   // Подписанный пре-ключ
	Signature      string   `json:"signature"`        // Подпись для SignedPreKey
	OneTimePreKeys []string `json:"one_time_pre_keys"` // Одноразовые ключи для Forward Secrecy
}

// Message представляет зашифрованный пакет сообщения (Relay)
type Message struct {
	SenderID   string `json:"sender_id"`
	ReceiverID string `json:"receiver_id"`
	Payload    string `json:"payload"` // Зашифровано на клиенте через ChaCha20
	Timestamp  int64  `json:"timestamp"`
}
