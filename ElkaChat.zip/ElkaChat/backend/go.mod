module elkachat-backend

go 1.21

require (
	github.com/gin-gonic/gin v1.9.1
	github.com/google/uuid v1.4.0
	github.com/gorilla/websocket v1.5.1
)
